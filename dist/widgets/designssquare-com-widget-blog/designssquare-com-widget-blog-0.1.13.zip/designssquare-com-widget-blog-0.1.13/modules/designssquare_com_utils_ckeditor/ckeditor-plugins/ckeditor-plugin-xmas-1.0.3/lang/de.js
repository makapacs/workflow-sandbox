/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'de', {
	title: 'Weihnachten',
	signature: 'Das CKEditor-Team',
	wishes: '<p>Im Namen des $1Team<br>' +
			'Wir wünschen Ihnen...</p>' +
			'<p class="big">Frohe Weihnachten!</p>'
} );
