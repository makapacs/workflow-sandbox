﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'fr', {
	title: 'Fêtes',
	signature: 'L\'équipe CKEditor',
	wishes: '<p>L\'équipe $1vous souhaite…</p>' +
			'<p class="big">Des joyeuses fêtes!</p>'
} );
