CKEDITOR.plugins.setLang( 'googledocs', 'en', {
  button:         'Document',
  title:          'Document settings',
  settingsTab:    'Settings',
  selectDocument: 'Select the document',
  url:            'Link',
  alertUrl:       'Please type the document URL.',
  alertWidth:     'Width must be a whole number.',
  alertHeight:    'Height must be a whole number.',
  uploadTab:      'Upload',
  btnUpload:      'Send it to the Server'
});