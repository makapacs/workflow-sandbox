﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'en', {
	title: 'Xmas',
	signature: 'The CKEditor Team',
	wishes: '<p>On behalf of the $1team<br>' +
			'We wish you...</p>' +
			'<p class="big">Happy Holidays!</p>'
} );
