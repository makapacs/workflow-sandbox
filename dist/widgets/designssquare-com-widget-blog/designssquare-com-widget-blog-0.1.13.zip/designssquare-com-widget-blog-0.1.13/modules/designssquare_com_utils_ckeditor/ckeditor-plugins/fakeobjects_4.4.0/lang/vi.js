﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'vi', {
	anchor: 'Điểm neo',
	flash: 'Flash',
	hiddenfield: 'Trường ẩn',
	iframe: 'IFrame',
	unknown: 'Đối tượng không rõ ràng'
} );
