﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'es', {
	title: 'Navidad!',
	signature: 'El equipo de CKEditor',
	wishes: '<p>Que tengas</p>' +
			'<p class="big">una feliz Navidad</p>' +
			'<p>y un maravilloso</p>' +
			'<p class="big">Año Nuevo!</p>'
} );
