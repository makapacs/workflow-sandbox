﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'tr', {
	alt: 'Alternatif Yazı',
	btnUpload: 'Sunucuya Yolla',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Resim Bilgisi',
	lockRatio: 'Oranı Kilitle',
	menu: 'Resim Özellikleri',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Boyutu Başa Döndür',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Resim Özellikleri',
	uploadTab: 'Karşıya Yükle',
	urlMissing: 'Resmin URL kaynağı eksiktir.'
} );
