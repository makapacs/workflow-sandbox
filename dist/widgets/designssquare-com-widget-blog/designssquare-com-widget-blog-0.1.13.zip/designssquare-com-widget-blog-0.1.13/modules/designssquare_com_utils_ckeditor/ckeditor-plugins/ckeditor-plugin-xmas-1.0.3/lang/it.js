﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'it', {
	title: 'Natale',
	signature: 'Il team CKEditor',
	wishes: '<p>Auguri di Buone Feste…</p>' +
			'<p class="big">Buon Natale!</p>' +
			'<p class="big">e</p>' +
			'<p class="big">Felice Anno Nuovo!</p>'
} );
