﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'bn', {
	anchor: 'Anchor', // MISSING
	flash: 'Flash Animation', // MISSING
	hiddenfield: 'Hidden Field', // MISSING
	iframe: 'IFrame', // MISSING
	unknown: 'Unknown Object' // MISSING
} );
