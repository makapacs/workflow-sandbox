
<?php foreach ($view->result as $id => $row): ?>
    <?php print $row->portfolio_project;?>
<?php endforeach; ?>

