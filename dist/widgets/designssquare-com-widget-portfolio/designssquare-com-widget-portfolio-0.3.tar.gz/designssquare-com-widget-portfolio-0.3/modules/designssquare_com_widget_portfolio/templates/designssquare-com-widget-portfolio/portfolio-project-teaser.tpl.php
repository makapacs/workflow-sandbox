

<div class="contextual-links-region">
        <?php print render($project_tapi['ds_contextual_links']);?>
    <a href="<?php print $project_tapi['url']?>"><img src="<?php print $project_tapi['featured_img']['url']?>" alt="<?php print $project_tapi['featured_img']['url']?>" class="thumbnail"></a>
    <h3><a href="<?php print $project_tapi['url']?>"><?php print $project_tapi['title'];?></a></h3>
    <?php print $project_tapi['summary'];?>
</div>


