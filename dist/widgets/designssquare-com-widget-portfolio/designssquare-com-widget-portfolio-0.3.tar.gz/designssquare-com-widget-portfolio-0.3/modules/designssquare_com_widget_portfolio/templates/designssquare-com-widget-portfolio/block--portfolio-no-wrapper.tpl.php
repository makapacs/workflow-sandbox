
<?php print $content ?>
