<div class="widget">
    <h3 class="widget-title">Recent Posts</h3>
    <ul class="nav">
        <li><a href="/">The Emerald City of Oz</a></li>
        <li><a href="/">Yellow Brick Road</a></li>
        <li><a href="/">Somewhere Over The Rainbow</a></li>
    </ul>
</div>