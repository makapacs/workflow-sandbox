
<div class="<?php print $context['classes'];?>">
    <?php print render($block_api['contextual_links']);?>
    <div class="jumbotron">
<!--    <h2 class="lead">A clean, minimal, responsive blog &amp; portfolio theme for businesses &amp; creatives</h2>-->
    <?php print $block_api['content'];?>
</div>
</div>