<div class="<?php print $context['classes'];?>">
    <?php print render($block_api['contextual_links']);?>
    <h3 class="widget-title"><?php print $block_api['title']; ?></h3>
    <?php print $block_api['content']; ?>
<!--    <ul class="nav">-->
<!--        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Books</a></li>-->
<!--        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Travel</a></li>-->
<!--        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Portfolio</a></li>-->
<!--        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Music</a></li>-->
<!--    </ul>-->
</div>