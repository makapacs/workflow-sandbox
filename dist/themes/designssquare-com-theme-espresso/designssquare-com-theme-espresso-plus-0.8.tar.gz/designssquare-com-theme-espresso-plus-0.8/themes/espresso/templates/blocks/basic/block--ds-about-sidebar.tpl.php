<div class="widget">
    <h3 class="widget-title">About Me</h3>
    <p><a href="/about">
            <img src="<?php print base_path().drupal_get_path('module', DS_TARGET_MODULE) . '/assets/' ?>img/bio-lg.jpg" alt="Placeholder" width="70" height="54" class="right thumbnail img-responsive">
        </a>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat.</p>
</div>