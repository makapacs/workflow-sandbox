<div class="widget">
    <h3 class="widget-title">Archives</h3>
    <ul class="nav">
        <li><a href="archives.html"><span class="glyphicon glyphicon-calendar"></span> 2007</a></li>
        <li><a href="archives.html"><span class="glyphicon glyphicon-calendar"></span> 2008</a></li>
        <li><a href="archives.html"><span class="glyphicon glyphicon-calendar"></span> 2009</a></li>
        <li><a href="archives.html"><span class="glyphicon glyphicon-calendar"></span> 2010</a></li>
        <li><a href="archives.html"><span class="glyphicon glyphicon-calendar"></span> 2011</a></li>
        <li><a href="archives.html"><span class="glyphicon glyphicon-calendar"></span> 2012</a></li>
    </ul>
</div>