<div class="widget">
    <h3 class="widget-title">Categories</h3>
    <ul class="nav">
        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Books</a></li>
        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Travel</a></li>
        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Portfolio</a></li>
        <li><a href="categories.html"><span class="glyphicon glyphicon-list"></span> Music</a></li>
    </ul>
</div>