<div class="footer">
    <div class="row">
        <div class="col-sm-6">
            <?php print render($region['footer']); ?>
        </div>
        <div class="col-sm-6">
            <?php print render($region['footer_navigation']); ?>
        </div>
    </div>
</div>