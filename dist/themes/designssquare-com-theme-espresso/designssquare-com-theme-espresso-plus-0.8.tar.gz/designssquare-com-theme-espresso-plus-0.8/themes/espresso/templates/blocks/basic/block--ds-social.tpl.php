<div class="widget">
    <h3 class="widget-title">Elsewhere</h3>
    <ul class="nav">
        <li><a href="/"><span class="glyphicon glyphicon-link"></span> Twitter</a></li>
        <li><a href="/"><span class="glyphicon glyphicon-link"></span> Facebook</a></li>
        <li><a href="/"><span class="glyphicon glyphicon-link"></span> Flickr</a></li>
        <li><a href="/"><span class="glyphicon glyphicon-link"></span> Last.fm</a></li>
    </ul>
</div>