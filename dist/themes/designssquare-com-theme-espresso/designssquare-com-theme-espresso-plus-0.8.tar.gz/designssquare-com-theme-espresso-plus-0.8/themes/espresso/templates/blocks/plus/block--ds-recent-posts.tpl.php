<div class="col-sm-6 row-element">
    <h3>Recent Post</h3>

    <h2><a href="blog-single.html">The Emerald City of Oz</a></h2>

    <p>"That is true," said the Scarecrow. "You see," he continued confidentially, "I don't mind my legs and
        arms and body being stuffed, because I cannot get hurt. If anyone treads on my toes or sticks a pin into
        me, it doesn't matter, for I can't feel it. But I do not want people to call me a fool, and if my head
        stays stuffed with straw instead of with brains, as yours is, how am I ever to know anything?"</p>

    <p><a href="blog-single.html"><strong>Continue reading</strong> <i class="icon-arrow-right icon-white"></i></a>
    </p>
</div>