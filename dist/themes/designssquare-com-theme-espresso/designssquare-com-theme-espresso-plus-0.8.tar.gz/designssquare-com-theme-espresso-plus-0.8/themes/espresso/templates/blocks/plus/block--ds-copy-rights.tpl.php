<div class="<?php print $context['classes'];?>">
    <?php print render($block_api['contextual_links']);?>
    <?php print $block_api['content'];?>
    <!--    <p>&copy; Copyright Espresso Theme</p>-->
</div>
