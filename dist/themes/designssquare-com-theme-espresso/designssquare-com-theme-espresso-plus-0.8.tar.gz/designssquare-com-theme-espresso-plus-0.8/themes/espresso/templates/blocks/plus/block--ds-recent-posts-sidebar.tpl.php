<div class="<?php print $context['classes'];?>">
    <?php print render($block_api['contextual_links']);?>
    <h3 class="widget-title"><?php print $block_api['title']; ?></h3>
    <?php print $block_api['content']; ?>
<!--        <ul class="nav">-->
<!--        <li><a href="/">The Emerald City of Oz</a></li>-->
<!--        <li><a href="/">Yellow Brick Road</a></li>-->
<!--        <li><a href="/">Somewhere Over The Rainbow</a></li>-->
<!--    </ul>-->
</div>