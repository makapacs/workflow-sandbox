<p>&copy; Copyright <a href="http://DesignsSquare.com" target="_blank">DesignsSquare.com</a></p>
