<div class="col-sm-3 row-element">
    <h3>Recent Tweet</h3>
    <blockquote>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
    </blockquote>
    <p><a href="/" class="btn btn-info btn-mini"><strong>Follow me on Twitter</strong></a></p>
</div>