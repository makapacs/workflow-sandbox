
<div class="col-sm-12">
<div class="jumbotron">
    <h2 class="lead">A clean, minimal, responsive blog &amp; portfolio theme for businesses &amp; creatives</h2>
</div>
</div>